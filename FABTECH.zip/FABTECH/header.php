<!DOCTYPE html>
<html>
<head>
	<title></title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
          <link href="https://fonts.googleapis.com/css?family=PT+Sans" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Playfair+Display" rel="stylesheet">
       <link href="https://fonts.googleapis.com/css?family=Josefin+Sans:300,400,700&subset=latin-ext" rel="stylesheet">
    <?php wp_head(); ?>
</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">


    <div id="page">
      
    

<nav id="nav" class="navbar navbar-custom navbar-fixed-top" role="navigation">


        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
         
<div class="header">
        <a href="#menu"><span></span></a>
     
      </div>

      <nav id="menu">

          <?php wp_nav_menu(array(
            'container_class' => 'menu-header',
            'theme_location' => 'primary',
            'items_wrap' => '<ul id="%1$s" class="%2$s ">%3$s</ul>',
            'walker' => new BS3_Walker_Nav_Menu,
            'menu' => 'Home'
          )); ?>

      </nav>
         <!--  <a class="navbar-brand" href="#"></a> -->
        </div>

  <?php
   $the_query = new WP_Query(array(
    'category_name' => 'LOGO', 
    'posts_per_page' => 1

    )); 
   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>

<!-- <div class="container"> -->
<a class="brand" href="#"><img src="<?php the_post_thumbnail_url('full');?>" alt="#"></a>
        <!-- Collect the nav links, forms, and other content for toggling -->


        <div class="collapse  navbar-collapse navbar-ex1-collapse">
            <ul class="nav navbar-nav navbar-right">
         <li><div id="search"><a href="#"><img src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/search_05.png" alt="#"></a></div></li> 
        </ul>
          <?php wp_nav_menu(array(
            'container_class' => 'menu-header',
            'theme_location' => 'primary',
            'items_wrap' => '<ul id="%1$s" class="%2$s nav navbar-nav navbar-right">%3$s</ul>',
            'walker' => new BS3_Walker_Nav_Menu,
            'menu' => 'Home'
          )); ?>
     </div>
      <?php 
   endwhile; 
   wp_reset_postdata();
  ?>
<!--   </div> -->
</nav>




<?php if (is_front_page()) : ?>

<section id="banner">
<div class="container-full">
  <div id="myCarousel" class="carousel fade-carousel carousel-fade slide" data-ride="carousel" data-interval="4000">


  <?php
   $the_query = new WP_Query(array(
   	'orderby' => 'Home Slider',
	  'order'   => 'ASC',
    // 'category_name' => 'Home Slider', 
    'post_type' => 'Slider',
    'posts_per_page' => 1

    )); 
   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>

    <div class="carousel-inner">

      <div class="item slides active">
         <div class="out"><div class="slide-1 brightness" style="background-image: url(<?php the_post_thumbnail_url('full');?>);"></div> </div>
          <div class="hero">
            <img src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/Forma-1-BANNER.png" alt="#">         
                <h2><?php the_title();?></h2>        
                <p><?php the_content();?></p>
             <a href="#"><img src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/gSbutton.png" alt="#" ></a>
            </div>
      </div>


      <?php 
   endwhile; 
   wp_reset_postdata();
  ?>
<?php 
   $the_query = new WP_Query(array(
   	 	'orderby' => 'Home Slider',
	'order'   => 'ASC',
  'post_type' => 'Slider',
    // 'category_name' => 'Home Slider', 
    'posts_per_page' => 50, 
    'offset' => 1
        )); 
   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>

      <div class="item slides">
       <div class="out"><div class="slide-2 brightness" style="background-image: url(<?php the_post_thumbnail_url('full');?>);" ></div> </div> 
          <div class="hero">        
              <img src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/Forma-1-BANNER.png" alt="#">    
                <h2><?php the_title();?></h2>        
                <p><?php the_content();?></p>     
              <a href="#"><img src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/gSbutton.png" alt="#"></a>
          </div>
      </div>

   <?php 
   endwhile; 
   wp_reset_postdata();
  ?>
  </div> 
</div>
</div>
 	</section>

  
  <?php endif; ?>

