
<?php /* Template Name: page-our-services*/ ?>

<?php get_header(); ?>

<div class="container-fluid bgBlue">
<div class="allServices">	
	    <?php
   $the_query = new WP_Query(array(
'orderby' => 'SERVICES',
	'order'   => 'ASC',
	'post_type' => 'services',
    'posts_per_page' => 6

    )); 
   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>

  
						<table class="table-responsive">
					 	<!---*********SERVICES*******-->
					  <tr>
					    <td><img src="<?php the_post_thumbnail_url('full');?>" alt="#"></td> 
					    <td><h3><?php the_title();?></h3>
<p><?php the_content();?></p>
					    </td>
					    <!-- <tr><td><p>hello world</p><td></tr> -->
					  </tr>

					  </table>
	

<?php 
   endwhile; 
   wp_reset_postdata();
  ?>					  
</div>		
</div>
<?php get_footer(); ?>