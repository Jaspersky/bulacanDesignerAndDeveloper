



<footer class="nb-footer">
<div class="container">
	<div class="row">
		<div class="col-sm-12">
			<div class="about">
				<h3 class="text-center">Contacts</h3>
				<img  src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/horSep-26.png" alt="#">
				<h1 class="text-center">FIND US</h1> 
				
			</div>
		</div>
<div class="col-md-2"></div>
		<div class="col-md-3">
			<div class="footer-info-single">
<?php
   $the_query = new WP_Query(array(
    'category_name' => 'contactINFO', 
    'posts_per_page' => 1

    )); 

   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>

				<h2 class="title"><?php the_title();?></h2>
				<p><?php the_content();?></p>

<?php 
   endwhile; 
   wp_reset_postdata();
  ?>	
			</div>
		</div>
<div class="col-md-2"><img class="img-responsive" src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/footSep_39.png" alt="#"></div>
		<div class="col-md-3">
				<div class="footer-info-single">
					<h2 class="title">NEWS LETTER SIGNUP</h2>
					<p>Get in touch with us!</p>
					<div class="submmit">
						<input type="text" class="form-control input-sm" maxlength="64" placeholder="Email Address" />
					 	<button type="submit" class="btn btn-primary btn-sm">SUBMMIT</button>
					</div>
				</div>
			<div class="row">
				
				<div class="social-media">
				<h2>FOLLOW US</h2>	
					<ul class="list-inline">
<?php
   $the_query = new WP_Query(array(
    'category_name' => 'socialmedia', 
    'posts_per_page' => 3

    )); 

   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>
	<li><a href="#" title=""><img src="<?php the_post_thumbnail_url('full');?>" alt="#"></a></li>
<?php 
   endwhile; 
   wp_reset_postdata();
  ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
	<section class="copyright">
		<div class="container">
			<a class="page-scroll" href="#banner">
			<img  src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/arrowup.png" alt="#"></a>
			<div class="row">
				<div class="col-sm-4"></div>
				<div class="col-sm-4">
				
				<p>FABTECH. Copyright 2016. All Rights Reserved.</p>
				</div>
				<div class="col-sm-4"></div>
			</div>
		</div>
	</section>
</footer>

  </div>
</body>
</html>