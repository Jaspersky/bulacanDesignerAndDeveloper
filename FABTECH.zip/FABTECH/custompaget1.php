<?php /* Template Name: About */ ?>

<?php get_header(); ?>

<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>


<div class="container-fluid bgBlue">
	<section id="about"><div class="row"><div class="col-sm-12"><h3 class="text-center">About us</h3>
	<img  class="center-block" src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/horSep-26.png" alt="#">
	</div>
	</div>
	<section>
		  <div class="row">


	 		<div class="cont3"><h1 class="text-center"><?php the_title();?></h1></div> 
			   <div class="col-sm-5">
			   		<img class="img-responsive" src="<?php the_post_thumbnail_url('full');?>" alt="#">
			   	</div>

				<div class="col-sm-7">
				<section id="services">
					<p>
						<?php the_content();?> 
					</p>
	<?php endwhile; else : ?>
	<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>

<?php endif; ?>
 	

  	    <?php
   $the_query = new WP_Query(array(
	'orderby' => 'SERVICES',
	'order'   => 'ASC',
	'post_type' => 'services',
    // 'category_name' => 'SERVICES', 
    'posts_per_page' => 6

    )); 
   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>
						<table>
					 	<!---*********SERVICES*******-->
					  <tr>
					    <td><img src="<?php the_post_thumbnail_url('full');?>" alt="#"></td> 
					    <td><p><?php the_title();?></td> 
					  </tr>
					  </table>
<?php 
   endwhile; 
   wp_reset_postdata();
  ?>					  
					  </section>
		<!---*********SERVICES END*******-->
			</div>
		</div>
</div>




<?php
   $the_query = new WP_Query(array(
    'category_name' => 'ABOUTUS2', 
    'posts_per_page' => 1

    )); 

   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>
<div class="container-fluid">
	<div class="row">
				<div class="col-sm-5">
					<div class="centerized">
						<h1><?php the_title();?> </h1><br>
							<p>
								<?php the_content();?> 
							</p>
					</div>
				</div>
			<div class="col-lg-7 nopadding ">
				<img class="img-responsive" src="<?php the_post_thumbnail_url('full');?>" alt="#">
			</div>
	</div>
</div>


<?php 
   endwhile; 
   wp_reset_postdata();
  ?>	

<?php get_footer(); ?>