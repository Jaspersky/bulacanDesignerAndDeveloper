
<?php get_header();  ?>



<div class="container-fluid bgBlue">
	<section id="about"><div class="row"><div class="col-sm-12"><h3 class="text-center">About us</h3>
	<img  class="center-block" src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/horSep-26.png" alt="#">
	</div>
	</div>
	<section>
		  <div class="row">

		    <?php
   $the_query = new WP_Query(array(
    'post_type' => 'About',
    'posts_per_page' => 1

    )); 
   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>

	 		<div class="cont3"><h1 class="text-center"><?php the_title();?></h1></div> 
			   <div class="col-sm-5">
			   		<img class="img-responsive" src="<?php the_post_thumbnail_url('full');?>" alt="#">
			   	</div>

				<div class="col-sm-7">
				<section id="services">
					<p>
						<?php the_content();?> 
					</p>
<?php 
   endwhile; 
   wp_reset_postdata();
  ?>

  	    <?php
   $the_query = new WP_Query(array(
	'orderby' => 'SERVICES',
	'order'   => 'ASC',
	'post_type' => 'services',
    'posts_per_page' => 6

    )); 
   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>
		<table>
		<!---*********SERVICES*******-->
			 <tr>
				 <td><img src="<?php the_post_thumbnail_url('full');?>" alt="#"></td> <td><p><?php the_title();?></p></td> 
			</tr>
		</table>
<?php 
   endwhile; 
   wp_reset_postdata();
  ?>					  
					  </section>
		<!---*********SERVICES END*******-->
			</div>
		</div>
</div>
 <?php
   $the_query = new WP_Query(array(
    'category_name' => 'ABOUTUS2', 
    'posts_per_page' => 1

    )); 

   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>
<div class="container-fluid">
	<div class="row">
				<div class="col-sm-5">
					<div class="centerized">
						<h1><?php the_title();?> </h1>
							<p>
								<?php the_content();?> 
							</p>
					</div>
				</div>
			<div class="col-lg-7 nopadding ">
				<img class="img-responsive" src="<?php the_post_thumbnail_url('full');?>" alt="#">
			</div>
	</div>
</div>

<section id="products">
	<div class="container">
			<div class="products">
				<div class="row">
					<div class="col-sm-12">
<?php 
   endwhile; 
   wp_reset_postdata();
  ?>	

<?php
   $the_query = new WP_Query(array(
    'category_name' => 'ourProductsContent', 
    'posts_per_page' => 1

    )); 
   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>
						<h3 class="text-center"><?php the_title();?></h3>
						<img  class="center-block" src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/horSep-26.png" alt="#">
						<div class="cont3"><h1 class="text-center"><?php the_content();?></h1></div>
<?php 
   endwhile; 
   wp_reset_postdata();
  ?>	
					</div>
				</div>
			</div>
	</div>
	
	
<!--****************WOODYIMAGE*********************-->
	<div class="products2 ">
			<div class="container ">


<!--##########START OF FEATURED PRODUCTS FIRST ROW##########-->
				<div class="row">
					<div class="col-md-4 nopadding">
				<?php
   $the_query = new WP_Query(array(
   	 
   	'category_name' => 'Featured Product',
	'order'   => 'DESC',
	'post_type' => 'Products',
    // 'category_name' => 'Featured Product', 
    'posts_per_page' => 1

    )); 
   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>
  			
					<a href="#"><img class="img-responsive featured-item" src="<?php the_post_thumbnail_url();?>" alt="#"></a>
					</div>
					<div class="col-md-4 nopadding">
			<div class="left-arrow">
					<h3 class="text-center"><?php the_title();?></h3> 
					<img class ="smSeparator img-responsive center-block" src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/horSep-26.png" alt="#">
					<p class="text-center">
					<?php the_content();?>
					</p>
					<a href="#">
					<img class="smButton img-responsive center-block" src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/view-more.png" alt="#">
					</a>
					</div>
					</div>

<?php 
   endwhile; 
   wp_reset_postdata();
  ?>	

			<?php
			   $the_query = new WP_Query(array(
			 	'category_name' => 'Featured Product',
	'order'   => 'DESC',
	'post_type' => 'Products', 
			    'posts_per_page' => 1,
			    'offset' => 2
			    )); 
			   while ( $the_query->have_posts() ) : 
			   $the_query->the_post();
			  ?>

					<div class="col-md-4 nopadding"><a
					 href="#">
					 <img  class="img-responsive featured-item" src="<?php the_post_thumbnail_url();?>" alt="#"></a>
					 </div>
			<?php 
			   endwhile; 
			   wp_reset_postdata();
			  ?>						 
</div>
<!--##########END OF FEATURED PRODUCTS FIRST ROW##########-->




		 	</div>

		 	<div class="container">
<!--##########START OF FEATURED PRODUCTS SECOND ROW##########-->
		<div class="row">
				<?php
   $the_query = new WP_Query(array(
 	'category_name' => 'Featured Product',
	'order'   => 'DESC',
	'post_type' => 'Products',
    'posts_per_page' => 1,
    'offset' => 1
    )); 
   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>
		
					<div class="col-md-4 nopadding">
<div class="right-arrow">
					<h3 class="text-center"><?php the_title();?></h3> 

					<img class ="smSeparator img-responsive center-block" src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/horSep-26.png" alt="#"> 
					<p class="centerText">
					<?php the_content();?>
					</p>
					<a href="#"><img class="smButton img-responsive center-block" src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/view-more.png" alt="#"></a>
					</div>
					</div>
					<div class="col-md-4 nopadding"><a href="#">
					<img  class="img-responsive featured-item" src="<?php the_post_thumbnail_url();?>" alt="#"></a>
					</div>
<?php 
   endwhile; 
   wp_reset_postdata();
  ?>

				<?php
   $the_query = new WP_Query(array(
    'orderby' => 'featuredProduct1',
	'order'   => 'ASC',
    'category_name' => 'featuredProduct1',
    'posts_per_page' => 1,
    'offset' => 2

    )); 
   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>
					<div class="col-md-4 nopadding">
					<div class="down-arrow">
					<h3 class="text-center"><?php the_title();?></h3>
					<img class ="smSeparator img-responsive center-block" src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/horSep-26.png" alt="#">  
					<p class="text-center"><?php the_content();?></p>
					<a href="#"><img class="smButton img-responsive center-block" src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/view-more.png" alt="#"></a>
					</div>
					</div>
<?php 
   endwhile; 
   wp_reset_postdata();
  ?>	

				</div>
<!--##########END OF FEATURED PRODUCTS SECOND ROW##########-->		
			</div>	


<a href="#"><img class="img-responsive middle" src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/view-all.png" alt="#"></a>
	</div>



</section>


<section id="products">

<div class="container-fluid bgBlue">
	 	 <div class="col-sm-12"><h3 class="text-center">Who We Are</h3><img  src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/horSep-26.png" alt="#">
			<div class="cont3"><h1 class="text-center">Partners & Support Team</h1></div>
	 	 </div>
	 	 <div id="demo">
	<div class="row">
        
		<div class="col-sm-1 nopadding">
			<div class="customNavigation">
			    <a class="left prev"><img src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/fabtech_30.png" alt="#" class="pull-left"></a>
			  <!-- 	<a class="right next"><img src="images/icons/fabtech_33.png" alt="#"></a> -->
			 </div>
		</div>
		<div class="col-md-10 nopadding">
              <div id="owl-demo" class="owl-carousel">



  <?php
   $the_query = new WP_Query(array(
   	'orderby' => 'partners',
	  'order'   => 'ASC',
    // 'category_name' => 'Home Slider', 
    'post_type' => 'partners',
    'posts_per_page' => 100

    )); 
   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>



                <div class="item">
		      		<div class="thumbnail_container">
				      <div class="thumbnail">
				     	<img src="<?php the_post_thumbnail_url('full');?>" alt="#">
				      </div>
				    </div>
                </div>
<?php 
   endwhile; 
   wp_reset_postdata();
  ?>	

              </div>
             </div>

    <div class="col-sm-1 nopadding">
    	<div class="customNavigation">
			   <!--  <a class="left prev"><img src="images/icons/fabtech_30.png" alt="#" class="center-block"></a> -->
			  	<a class="right next"><img src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/fabtech_33.png" class="pull-right" alt="#"></a>
			 </div>
    	</div>
  	</div>
  </div>
</div>
</section>




<script>
        var $el = $('#owl-demo');
        var breakpoints = {
            0: {items: 1},480: {items: 4},768: {items: 5}, 992: {items: 4},1200: {items: 5}
        };
        var carousel = $el.owlCarousel({

            loop:   true,
            margin: 10,
            nav:    false,
            dots:   false,
            responsive: breakpoints
        });

</script>
<?php get_footer(); ?>