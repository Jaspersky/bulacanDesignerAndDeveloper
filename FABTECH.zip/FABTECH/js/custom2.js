$('.carousel[data-type="multi"] .item').each(function(){
  var next = $(this).next();
  if (!next.length) {
    next = $(this).siblings(':first');
  }
  next.children(':first-child').clone().appendTo($(this));

  for (var i=0;i<3;i++) {
    next=next.next();
    if (!next.length) {
    	next = $(this).siblings(':first');
  	}
    next.children(':first-child').clone().appendTo($(this));
  }
});


        var $el = $('#owl-demo');
        var breakpoints = {
            0: {
                items: 2
            },
            480: {
                items: 4
            },
            769: {
                items: 5
                  
            },
            992: {
                items: 4
            },
            1200: {
                items: 5
               
            }
        };
        var carousel = $el.owlCarousel({

            loop:   true,
            margin: 10,
            nav:    false,
            dots:   false,
            responsive: breakpoints
        });

        // get real items count
        var items   = $el.find('.item:not(.cloned)').length;

        // $nav = your navigation element, mine is custom
        var $nav    = $el.parent().find('.center-navigation');

        // add responsive classes to hide navigation if needed
        if(breakpoints[1200].items>=items)  $nav.addClass('hidden-lg');
        if(breakpoints[992].items>=items)   $nav.addClass('hidden-md');
        if(breakpoints[769].items>=items)   $nav.addClass('hidden-sm');
        if(breakpoints[480].items>=items)   $nav.addClass('hidden-xs');
        if(breakpoints[0].items>=items)     $nav.addClass('hidden-xxs');



 $(document).ready(function() {
	owl = $('.owl-carousel').owlCarousel();
$(".prev").click(function () {
    owl.trigger('prev.owl.carousel');
});

$(".next").click(function () {
    owl.trigger('next.owl.carousel');
});
    });
//###########MMMENNU#################



  $(document).ready(function() {
      $("#my-menu").mmenu();
   });
$(function() {
                $('nav#menu').mmenu({
                    extensions  : [ 'fx-menu-slide', 'shadow-page', 'shadow-panels', 'listview-large', 'pagedim-white' ],
                    iconPanels  : true,
                    counters    : true,
                    keyboardNavigation : {
                        enable  : true,
                        enhance : true
                    },
                    searchfield : {
                        placeholder : 'Search menu items'
                    },
                    navbar : {
                        title : 'Advanced menu'
                    },
                    navbars : [
                        {
                            position    : 'top',
                            content     : [ 'searchfield' ]
                        }, {
                            position    : 'top',
                            content     : [ 'breadcrumbs', 'close' ]
                        }, {
                            position    : 'bottom',
                            content     : [ '<a href="http://mmenu.frebsite.nl/wordpress-plugin" target="_blank">WordPress plugin</a>' ]
                        }
                    ]
                }, {
                    searchfield : {
                        clear : true
                    }
                });
            });
