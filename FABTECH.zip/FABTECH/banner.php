<section id="banner">
<div class="container-full">
  <div id="myCarousel" class="carousel fade-carousel carousel-fade slide" data-ride="carousel" data-interval="4000">


  <?php
   $the_query = new WP_Query(array(
   	'orderby' => 'Home Slider',
	  'order'   => 'ASC',
    // 'category_name' => 'Home Slider', 
    'post_type' => 'Slider',
    'posts_per_page' => 1

    )); 
   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>

    <div class="carousel-inner">

      <div class="item slides active">
         <div class="out"><div class="slide-1 brightness" style="background-image: url(<?php the_post_thumbnail_url('full');?>);"></div> </div>
          <div class="hero">
            <img src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/Forma-1-BANNER.png" alt="#">         
                <h2><?php the_title();?></h2>        
                <p><?php the_content();?></p>
             <a href="#"><img src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/gSbutton.png" alt="#" ></a>
            </div>
      </div>


      <?php 
   endwhile; 
   wp_reset_postdata();
  ?>
<?php 
   $the_query = new WP_Query(array(
   	 	'orderby' => 'Home Slider',
	'order'   => 'ASC',
  'post_type' => 'Slider',
    // 'category_name' => 'Home Slider', 
    'posts_per_page' => 5, 
    'offset' => 1
        )); 
   while ( $the_query->have_posts() ) : 
   $the_query->the_post();
  ?>

      <div class="item slides">
       <div class="out"><div class="slide-2 brightness" style="background-image: url(<?php the_post_thumbnail_url('full');?>);" ></div> </div> 
          <div class="hero">        
              <img src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/Forma-1-BANNER.png" alt="#">    
                <h2><?php the_title();?></h2>        
                <p><?php the_content();?></p>     
              <a href="#"><img src="http://localhost:1234/wordpress/wp-content/uploads/2017/03/gSbutton.png" alt="#"></a>
          </div>
      </div>

   <?php 
   endwhile; 
   wp_reset_postdata();
  ?>
  </div> 
</div>
 	</section>