<?php

function fab_script_enqueque(){
	wp_enqueue_style( 'mainStyle', get_template_directory_uri().'/css/mainStyle.css', array(), '1.0.25', $media );
	wp_enqueue_style( 'bootstrap', get_template_directory_uri().'/css/bootstrap.min.css', array(), '1.0.0', $media );
	wp_enqueue_style( 'owlSlidercss', get_template_directory_uri().'/css/owl.carousel.min.css', array(), '1.0.0', $media );
	wp_enqueue_style( 'owlSliderTheme', get_template_directory_uri().'/css/owl.theme.css', array(), '1.0.0', $media );
	wp_enqueue_style( 'MMMenuStyle', get_template_directory_uri().'/dist/jquery.mmenu.all.css', array(), '1.0.0', $media );
	
	// wp_enqueue_script( 'customJQ', get_template_directory_uri().'/js/jquery.js', array(), '1.0.0', false);
	wp_enqueue_script( 'customJQS', get_template_directory_uri().'/js/jquery-3.2.0.js', array(), '1.0.0', false);
	wp_enqueue_script( 'customJS', get_template_directory_uri().'/js/bootstrap.min.js', array(), '1.0.0', false);
	wp_enqueue_script( 'owlSliderJS', get_template_directory_uri().'/js/owl.carousel.min.js', array(), '1.0.0', false);
	wp_enqueue_script( 'easing', get_template_directory_uri().'/js/jquery.easing.min.js', array(), '1.0.0', false);
	// wp_enqueue_script( 'scrolling-nav', get_template_directory_uri().'/js/scrolling-nav.js', array(), '1.0.0', false);
	wp_enqueue_script( 'customJS2', get_template_directory_uri().'/js/custom2.js', array(), '1.0.0', false);
	wp_enqueue_script( 'MMenuJS', get_template_directory_uri().'/dist/jquery.mmenu.all.min.js', array(), '1.0.0', false);
}
add_action( 'wp_enqueue_scripts', 'fab_script_enqueque');




function fab_theme_setup(){
	add_theme_support('menus');
	add_theme_support( 'post-thumbnails' ); 
	register_nav_menu('primary', 'Primary Header Navigation');
}
add_action( 'after_setup_theme', 'fab_theme_setup');

//NAVIGATION MENUSn

register_nav_menus(array(
	'primary' => __('Primary Menu'),
	));


class BS3_Walker_Nav_Menu extends Walker_Nav_Menu {

	function display_element( $element, &$children_elements, $max_depth, $depth, $args, &$output ) {
		$id_field = $this->db_fields['id'];

		if ( isset( $args[0] ) && is_object( $args[0] ) )
		{
			$args[0]->has_children = ! empty( $children_elements[$element->$id_field] );

		}

		return parent::display_element( $element, $children_elements, $max_depth, $depth, $args, $output );
	}

	function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
		if ( is_object($args) && !empty($args->has_children) && $item->menu_item_parent == 0 )
		{
			$link_after = $args->link_after;
			$args->link_after = ' <b class="caret"></b>';
		}

		parent::start_el($output, $item, $depth, $args, $id);

		if ( is_object($args) && !empty($args->has_children) )
			$args->link_after = $link_after;
	}

	function start_lvl( &$output, $depth = 0, $args = array() ) {
		$indent = '';
		$output .= "$indent<ul class=\"dropdown-menu list-unstyled\">";
	}
}


add_filter('nav_menu_link_attributes', 'nav_link_att', 10, 3);

function nav_link_att($atts, $item, $args) {
	if ( $args->has_children && $item->menu_item_parent == 0 )
	{
		$atts['data-toggle'] = 'dropdown';
		$atts['class'] = 'dropdown-toggle';
	}
	return $atts;
}

function fabtech_custom_post_type (){
	
	$labels = array(
		'name' => 'Slider',
		'singular_name' => 'slider',
		'add_new' => 'Add Item',
		'all_items' => 'All Items',
		'add_new_item' => 'Add Item',
		'edit_item' => 'Edit  ',
		'new_item' => 'New Item',
		'view_item' => 'View Item',
		'search_item' => 'Search Slider',
		'not_found' => 'No items found',
		'not_found_in_trash' => 'No items found in trash',
		'parent_item_colon' => 'Parent Item'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'supports' => array(
			'title',
			'editor',
			'excerpt',
			'thumbnail',
			'revisions',
		),
		'taxonomies' => array('category', 'post_tag'),
		'menu_position' => 5,
		'exclude_from_search' => false
	);


		$labels2 = array(
		'name' => 'About',
		'singular_name' => 'About',
		'add_new' => 'Add Item',
		'all_items' => 'All Items',
		'add_new_item' => 'Add Item',
		'edit_item' => 'Edit  ',
		'new_item' => 'New Item',
		'view_item' => 'View Item',
		'search_item' => 'Search About',
		'not_found' => 'No items found',
		'not_found_in_trash' => 'No items found in trash',
		'parent_item_colon' => 'Parent Item'
	);
	$args2 = array(
		'labels' => $labels2,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'supports' => array(
			'title',
			'editor',
			'excerpt',
			'thumbnail',
			'revisions',
		),
		'taxonomies' => array('category', 'post_tag'),
		'menu_position' => 5,
		'exclude_from_search' => false
	);
	$labels3 = array(
		'name' => 'Services',
		'singular_name' => 'Services',
		'add_new' => 'Add Item',
		'all_items' => 'All Items',
		'add_new_item' => 'Add Item',
		'edit_item' => 'Edit  ',
		'new_item' => 'New Item',
		'view_item' => 'View Item',
		'search_item' => 'Search Services',
		'not_found' => 'No items found',
		'not_found_in_trash' => 'No items found in trash',
		'parent_item_colon' => 'Parent Item'
	);
	$args3 = array(
		'labels' => $labels3,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'supports' => array(
			'title',
			'editor',
			'excerpt',
			'thumbnail',
			'revisions',
		),
		'taxonomies' => array('category', 'post_tag'),
		'menu_position' => 5,
		'exclude_from_search' => false
	);

		$labels4 = array(
		'name' => 'Partners',
		'singular_name' => 'Partners',
		'add_new' => 'Add Item',
		'all_items' => 'All Items',
		'add_new_item' => 'Add Item',
		'edit_item' => 'Edit  ',
		'new_item' => 'New Item',
		'view_item' => 'View Item',
		'search_item' => 'Search Partners',
		'not_found' => 'No items found',
		'not_found_in_trash' => 'No items found in trash',
		'parent_item_colon' => 'Parent Item'
	);
	$args4 = array(
		'labels' => $labels4,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'supports' => array(
			'title',
			'editor',
			'excerpt',
			'thumbnail',
			'revisions',
		),
		'taxonomies' => array('category', 'post_tag'),
		'menu_position' => 5,
		'exclude_from_search' => false
	);

	$labels5 = array(
		'name' => 'Products',
		'singular_name' => 'Products',
		'add_new' => 'Add Item',
		'all_items' => 'All Items',
		'add_new_item' => 'Add Item',
		'edit_item' => 'Edit  ',
		'new_item' => 'New Item',
		'view_item' => 'View Item',
		'search_item' => 'Search Products',
		'not_found' => 'No items found',
		'not_found_in_trash' => 'No items found in trash',
		'parent_item_colon' => 'Parent Item'
	);
	$args5 = array(
		'labels' => $labels5,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'supports' => array(
			'title',
			'editor',
			'excerpt',
			'thumbnail',
			'revisions',
		),
		'taxonomies' => array('category', 'post_tag'),
		'menu_position' => 5,
		'exclude_from_search' => false
	);
	register_post_type('slider',$args);
	// register_post_type('About',$args2);
	register_post_type('Services',$args3);
	register_post_type('Partners',$args4);
	register_post_type('Products',$args5);
}
add_action('init','fabtech_custom_post_type');

add_action( 'wp_ajax_demo_load_my_posts', 'demo_load_my_posts' );
add_action( 'wp_ajax_nopriv_demo_load_my_posts', 'demo_load_my_posts' ); 
function demo_load_my_posts() {
        
    global $wpdb; 
    
    $msg = '';
    
    if( isset( $_POST['data']['page'] ) ){
        // Always sanitize the posted fields to avoid SQL injections
        $page = sanitize_text_field($_POST['data']['page']); // The page we are currently at
        $name = sanitize_text_field($_POST['data']['th_name']); // The name of the column name we want to sort
        $sort = sanitize_text_field($_POST['data']['th_sort']); // The order of our sort (DESC or ASC)
        $cur_page = $page;
        $page -= 1;
        $per_page = 2; // Number of items to display per page
        $previous_btn = true;
        $next_btn = true;
        $first_btn = true;
        $last_btn = true;
        $start = $page * $per_page;
        
        // The table we are querying from   
        $posts = $wpdb->prefix . "posts";
        $posts2 = $wpdb->prefix . "postmeta";

        $where_search = '';
        
        // Check if there is a string inputted on the search box
        if( ! empty( $_POST['data']['search']) ){
            // If a string is inputted, include an additional query logic to our main query to filter the results
            $where_search = ' AND (post_title LIKE "%%' . $_POST['data']['search'] . '%%" OR post_content LIKE "%%' . $_POST['data']['search'] . '%%") ';
        }
        
        // Retrieve all the posts
        $all_posts = $wpdb->get_results($wpdb->prepare("
            SELECT * FROM $posts WHERE post_type = 'products' AND post_status = 'publish' $where_search 
            ORDER BY $name $sort LIMIT %d, %d", $start, $per_page ) );
        
        $count = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(ID) FROM " . $posts . " WHERE post_type = 'products' AND post_status = 'publish' $where_search", array() ) );

        // Check if our query returns anything.
        if( $all_posts ):
            $msg .= '<table class = "table table-striped table-hover table-file-list">';
            // $msg .= '<h4>';
            // Iterate thru each item
            foreach( $all_posts as $key => $post ): 
                $msg .= '
               <tr>
                    <td width = "25%"><a href = "' . get_permalink( $post->ID ) . '">' . $post->post_title. '</a></td>
                    <td width = "30%">' . $post->post_excerpt . '</td>
                    
                      <td width = "15%">' . $post->post_date . '</td>

                </tr>';

	
// '<a href ="' . get_permalink( $post->ID ) . '">' . $post->post_title .'</a>';	
            endforeach;
            
            $msg .= '</table>';
        // $msg .='</h4>';
        // If the query returns nothing, we throw an error message
        else:
            $msg .= '<p class = "bg-danger">No posts matching your search criteria were found.</p>';
            
        endif;

        $msg = "<div class='cvf-universal-content'>" . $msg . "</div><br class = 'clear' />";
        
        $no_of_paginations = ceil($count / $per_page);

        if ($cur_page >= 7) {
            $start_loop = $cur_page - 3;
            if ($no_of_paginations > $cur_page + 3)
                $end_loop = $cur_page + 3;
            else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
                $start_loop = $no_of_paginations - 6;
                $end_loop = $no_of_paginations;
            } else {
                $end_loop = $no_of_paginations;
            }
        } else {
            $start_loop = 1;
            if ($no_of_paginations > 7)
                $end_loop = 7;
            else
                $end_loop = $no_of_paginations;
        }
          
        $pag_container .= "
        <div class='cvf-universal-pagination'>
            <ul>";

        if ($first_btn && $cur_page > 1) {
            $pag_container .= "<li p='1' class='active'>First</li>";
        } else if ($first_btn) {
            $pag_container .= "<li p='1' class='inactive'>First</li>";
        } 

        if ($previous_btn && $cur_page > 1) {
            $pre = $cur_page - 1;
            $pag_container .= "<li p='$pre' class='active'>Previous</li>";
        } else if ($previous_btn) {
            $pag_container .= "<li class='inactive'>Previous</li>";
        }
        for ($i = $start_loop; $i <= $end_loop; $i++) {

            if ($cur_page == $i)
                $pag_container .= "<li p='$i' class = 'selected' >{$i}</li>";
            else
                $pag_container .= "<li p='$i' class='active'>{$i}</li>";
        }
        
        if ($next_btn && $cur_page < $no_of_paginations) {
            $nex = $cur_page + 1;
            $pag_container .= "<li p='$nex' class='active'>Next</li>";
        } else if ($next_btn) {
            $pag_container .= "<li class='inactive'>Next</li>";
        }

        if ($last_btn && $cur_page < $no_of_paginations) {
            $pag_container .= "<li p='$no_of_paginations' class='active'>Last</li>";
        } else if ($last_btn) {
            $pag_container .= "<li p='$no_of_paginations' class='inactive'>Last</li>";
        }

        $pag_container = $pag_container . "
            </ul>
        </div>";
        
        echo 
        '<div class = "cvf-pagination-content">' . $msg . '</div>' . 
        '<div class = "cvf-pagination-nav">' . $pag_container . '</div>';
    }
    
    exit();
    
}

function sct_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Banner Area', 'sct' ),
        'id'            => 'banner-area',
        'description'   => __( 'Add widgets here to appear in your sidebar.', 'sct' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s banner-area">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );

    register_sidebar( array(
        'name'          => __( 'Header Deatails', 'sct' ),
        'id'            => 'header-details',
        'description'   => __( 'Add widgets here to appear in your footer.', 'sct' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s header-details">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );

    register_sidebar( array(
        'name'          => __( 'Footer', 'sct' ),
        'id'            => 'footer',
        'description'   => __( 'Add widgets here to appear in your footer.', 'sct' ),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'sct_widgets_init' );
