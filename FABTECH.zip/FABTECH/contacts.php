<?php /* Template Name: Contacts*/ ?>

<?php get_header(); ?>

<?php get_footer(); ?>

